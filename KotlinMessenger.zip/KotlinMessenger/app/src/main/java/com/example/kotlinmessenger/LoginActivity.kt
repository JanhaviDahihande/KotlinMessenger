package com.example.kotlinmessenger

import android.os.Bundle
import android.os.PersistableBundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        login_button.setOnClickListener {

            val emailLogin = email_edittext_login.text.toString()
            val passwordPassword = password_edittext_login.text.toString()

            Log.d("LoginActivity", "Email is: $emailLogin")
            Log.d("LoginActivity", "Password is: $passwordPassword")
        }

        create_account_textview.setOnClickListener {
            finish()
        }
    }
}